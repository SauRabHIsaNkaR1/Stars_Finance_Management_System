package com.starssfinanceapp.app.controller;

public class ManagerController {

}

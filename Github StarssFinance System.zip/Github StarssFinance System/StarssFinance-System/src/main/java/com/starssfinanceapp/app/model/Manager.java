package com.starssfinanceapp.app.model;

public class Manager {

}

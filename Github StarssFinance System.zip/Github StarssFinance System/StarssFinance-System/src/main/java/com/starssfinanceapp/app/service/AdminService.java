package com.starssfinanceapp.app.service;

import java.util.List;

import com.starssfinanceapp.app.model.Admin;

public interface AdminService {

	public Admin savesbankdata(Admin ad);

	public List<Admin> getdata();

}

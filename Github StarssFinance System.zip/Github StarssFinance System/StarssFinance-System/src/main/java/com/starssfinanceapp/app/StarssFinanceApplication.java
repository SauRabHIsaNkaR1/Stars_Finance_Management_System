package com.starssfinanceapp.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StarssFinanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StarssFinanceApplication.class, args);
	}

}

package com.starssfinanceapp.app.repository;

public interface ManagerRepository {

}

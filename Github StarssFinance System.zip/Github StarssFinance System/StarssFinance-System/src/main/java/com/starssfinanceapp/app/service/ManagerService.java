package com.starssfinanceapp.app.service;

public interface ManagerService {

}

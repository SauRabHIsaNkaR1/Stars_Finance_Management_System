package com.starssfinanceapp.app.serviceImpl;

public class ManagerServiceImpl {

}
